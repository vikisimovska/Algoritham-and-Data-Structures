public class Tester2 {

	//generic version of the kthElement method
	public static <T extends Comparable<? super T>> T kthElement(T[] a, int k)
	{
		MaxHeapInterface<T> heap = new MaxHeap<>();
		
		if(k < 1 || k > a.length)
			throw new IllegalArgumentException("You have entered invalid parametar! ");

		for(int i = 0; i < k; i++)
		{
			heap.add(a[i]);
		}
		for(int y = k; y < a.length; y++)
		{
			int compare = a[y].compareTo(heap.getMax());
			if(compare < 0)
			{
				heap.removeMax();
				heap.add(a[y]);
			}
		}

		System.out.println("the " + k + " smallest number is " + heap.getMax());
		return heap.getMax();
	}

	public static void main(String[] args) {
		
		String [] a = { "a","b","c","d","e","f","g", "h", "i", "g"};
		kthElement(a, 1);
		kthElement(a, 5);
		kthElement(a, 10);
	}

}
