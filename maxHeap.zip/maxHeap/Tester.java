public class Tester {

	public static int kthElement(int[] a, int k)
	{
		if(k < 1 || k > a.length)
			throw new IllegalArgumentException("You have entered invalid parametar! ");
		
		MaxHeapInterface<Integer> heap = new MaxHeap<>();
		
		for(int i = 0; i < k; i++)
		{
			heap.add(a[i]);
		}
		for(int y = k; y < a.length; y++)
		{
			if(a[y] < heap.getMax())
			{
				heap.removeMax();
				heap.add(a[y]);
			}
		}
		System.out.println("the " + k + " smallest number is " + heap.getMax());
		return heap.getMax();
	}
	
	public static void main(String[] args) {
		
		int[] a = { 23,15,16,18,17,19,20, 12, 22, 14};
		kthElement(a, 1);
		kthElement(a, 2);
		kthElement(a, 3);
	}
	
}
